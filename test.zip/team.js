var styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:after {top: " + 2.24 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

//styleElem.innerHTML = ".silhouettes_flex_div:after {margin-left: " + 1.78 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:after {width: " + 6 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:after {height: " + 0.11 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:after {top: " + 0.28 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

//styleElem.innerHTML = ".silhouettes2_flex_div:after {margin-left: " + 1.74 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:after {width: " + 6 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:after {height: " + 0.11 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:hover:after {top: " + 2.24 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

//styleElem.innerHTML = ".silhouettes_flex_div:hover:after {margin-left: " + 1.78 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:hover:after {width: " + 6 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes_flex_div:hover:after {height: " + 0.11 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:hover:after {top: " + 0.28 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

//styleElem.innerHTML = ".silhouettes2_flex_div:hover:after {margin-left: " + 1.74 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:hover:after {width: " + 6 + "vw;}";

styleElem = document.head.appendChild(document.createElement("style"));

styleElem.innerHTML = ".silhouettes2_flex_div:hover:after {height: " + 0.11 + "vw;}";
