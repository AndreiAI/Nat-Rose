function contactUsTop(e) {
    var all = document.getElementsByTagName('h1');
    for (var i = 0; i < all.length; i++) {
        all[i].style.top = e.value + "vw";
    }
}

function toFindTop(e) {
    var all = document.getElementsByClassName('toFind');
    for (var i = 0; i < all.length; i++) {
        all[i].style.top = e.value + "vw";
    }
}

function toFindFontSize(e) {
    var all = document.getElementsByClassName('toFind');
    for (var i = 0; i < all.length; i++) {
        all[i].style.fontSize = e.value + "vw";
    }
}

function circlesMarginTop(e) {
    var all = document.getElementsByClassName('circle_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function circlesMargins(e) {
    var all = document.getElementsByClassName('circle_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function circleMargins(e) {
    var all = document.getElementsByClassName('circle_flex_div');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function circleSize(e) {
    var all = document.getElementsByClassName('circle_img');
    for (var i = 0; i < all.length; i++) {
        all[i].style.width = e.value + "vw";
    }
}
//
function ping1MarginTop(e) {
    var all = document.getElementById('ping_img1');

    all.style.top = e.value + "vw";
}

function ping1MarginLeft(e) {
    var all = document.getElementById('ping_img1');

    all.style.left = e.value + "vw";
}

function ping1Height(e) {
    var all = document.getElementById('ping_img1');

    all.style.height = e.value + "vw";
}
//
function ping2MarginTop(e) {
    var all = document.getElementById('ping_img2');

    all.style.top = e.value + "vw";
}

function ping2MarginLeft(e) {
    var all = document.getElementById('ping_img2');

    all.style.left = e.value + "vw";
}

function ping2Height(e) {
    var all = document.getElementById('ping_img2');

    all.style.height = e.value + "vw";
}
//
function ping3MarginTop(e) {
    var all = document.getElementById('ping_img3');

    all.style.top = e.value + "vw";
}

function ping3MarginLeft(e) {
    var all = document.getElementById('ping_img3');

    all.style.left = e.value + "vw";
}

function ping3Height(e) {
    var all = document.getElementById('ping_img3');

    all.style.height = e.value + "vw";
}
//
function ping4MarginTop(e) {
    var all = document.getElementById('ping_img4');

    all.style.top = e.value + "vw";
}

function ping4MarginLeft(e) {
    var all = document.getElementById('ping_img4');

    all.style.left = e.value + "vw";
}

function ping4Height(e) {
    var all = document.getElementById('ping_img4');

    all.style.height = e.value + "vw";
}
//
function ping5MarginTop(e) {
    var all = document.getElementById('ping_img5');

    all.style.top = e.value + "vw";
}

function ping5MarginLeft(e) {
    var all = document.getElementById('ping_img5');

    all.style.left = e.value + "vw";
}

function ping5Height(e) {
    var all = document.getElementById('ping_img5');

    all.style.height = e.value + "vw";
}
//
function ping6MarginTop(e) {
    var all = document.getElementById('ping_img6');

    all.style.top = e.value + "vw";
}

function ping6MarginLeft(e) {
    var all = document.getElementById('ping_img6');

    all.style.left = e.value + "vw";
}

function ping6Height(e) {
    var all = document.getElementById('ping_img6');

    all.style.height = e.value + "vw";
}
//
function ping7MarginTop(e) {
    var all = document.getElementById('ping_img7');

    all.style.top = e.value + "vw";
}

function ping7MarginLeft(e) {
    var all = document.getElementById('ping_img7');

    all.style.left = e.value + "vw";
}

function ping7Height(e) {
    var all = document.getElementById('ping_img7');

    all.style.height = e.value + "vw";
}
//
function yourDetailsDivTop(e) {
    var all = document.getElementsByClassName('yourDetails');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function yourDetailsMarginTop(e) {
    var all = document.getElementsByClassName('yourDetails_form_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function yourDetailsMargins(e) {
    var all = document.getElementsByClassName('yourDetails_form_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function yourDetailMargins(e) {
    var all = document.getElementsByClassName('yourDetails_form_flex_div');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function yourDetailWidth(e) {
    var all = document.getElementsByClassName('yourDetails_form_flex_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.width = e.value + "vw";
    }
}

function yourDetailHeight(e) {
    var all = document.getElementsByClassName('yourDetails_form_flex_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.height = e.value + "vw";
    }
}

function typeEnquirysDivTop(e) {
    var all = document.getElementsByClassName('typeEnquiry');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function typeEnquirysMarginTop(e) {
    var all = document.getElementsByClassName('typeEnquiry_form_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function typeEnquirysMargins(e) {
    var all = document.getElementsByClassName('typeEnquiry_form_flex');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function typeEnquiryMargins(e) {
    var all = document.getElementsByClassName('typeEnquiry_form_flex_div');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginLeft = all[i].style.marginRight = e.value + "vw";
    }
}

function typeEnquiryWidth(e) {
    var all = document.getElementsByClassName('typeEnquiry_form_flex_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.width = e.value + "vw";
    }
}

function typeEnquiryHeight(e) {
    var all = document.getElementsByClassName('typeEnquiry_form_flex_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.height = e.value + "vw";
    }
}

function briefDescriptionDivTop(e) {
    var all = document.getElementsByClassName('briefDescription');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function briefDescriptionMarginTop(e) {
    var all = document.getElementsByClassName('briefDescription_form_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.marginTop = e.value + "vw";
    }
}

function briefDescriptionRectangleWidth(e) {
    var all = document.getElementsByClassName('briefDescription_form_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.width = e.value + "%";
    }
}

function briefDescriptionRectangleHeight(e) {
    var all = document.getElementsByClassName('briefDescription_form_div_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.height = e.value + "vw";
    }
}

function clickSubmitTop(e) {
    var all = document.getElementsByClassName('clickSubmit');
    for (var i = 0; i < all.length; i++) {
        all[i].style.top = e.value + "vw";
    }
}

function clickSubmitRectangleWidth(e) {
    var all = document.getElementsByClassName('clickSubmit_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.width = e.value + "vw";
    }
}

function clickSubmitRectangleHeight(e) {
    var all = document.getElementsByClassName('clickSubmit_rectangle');
    for (var i = 0; i < all.length; i++) {
        all[i].style.height = e.value + "vw";
    }
}
